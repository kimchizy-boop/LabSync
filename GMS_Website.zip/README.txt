GMS WEBSITE SETUP

1. Put LabSync.zip in this folder beside index.html.
2. The ZIP should contain:
   - LabSync.exe
   - GadgetMonitoringSystem.jar
   - jre/
   - lib/
3. Open index.html to preview the website.
4. Upload index.html, assets/, and LabSync.zip to your web host.

Important: plain HTML cannot permanently upload new files to a public server.
The App Update picker is only a browser-side selector. A backend/storage service
is required for real online uploads.
